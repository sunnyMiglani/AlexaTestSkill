"use strict"

module.exports = {
    checkLocal : function(){
        const testFolder = './';
        const fs = require('fs');

        fs.readdirSync(testFolder).forEach(file => {
            console.log(file);
        })
        return " Found Local Files! ";
    },
    
    execGetEntities : function(){
        console.log("Am trying execute as my method");
        var exec = require('child_process').exec;
        exec('python detectEntities.py', function (error, stdout, stderr) {
            console.log("Excecuted! ");
            console.log('', stdout);
            if (error !== null) {
                console.log('exec error: ', error);
            }
            else{
                console.log("Abey yaar");
            }
        });
    },

    getEntities: function(){
        var spawn = require('child_process').spawn;
        var py = spawn('python', ['detectEntities.py']);
        var outputString = "starting string";
        
        py.stdout.on('data', function (data) {
            console.log("Getting information from the python script! ");
            outputString += data.toString();
            console.log(outputString);
        });
        

        py.stdout.on('end', function () {
            console.log("My output : " + outputString);
        });
        return outputString;

    }   
}