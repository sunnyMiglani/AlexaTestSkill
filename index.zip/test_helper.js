"use strict"

var spawn = require('child_process').spawn;
var py = spawn('python', ['detectEntities.py']);
var outputString = "starting string";

py.stdout.on('data', function(data) {
    console.log("Getting information from the python script! ");
    outputString += data.toString();
    console.log(outputString);
});


py.stdout.on('end', function () {
    console.log("My output : " + outputString);
});
